classdef Container < matlab.ui.container.internal.UIContainer
    %uix.Container  Container base class
    %
    %  uix.Container is base class for containers that extend uicontainer.
    
    %  Copyright 2009-2020 The MathWorks, Inc.
    
end % classdef